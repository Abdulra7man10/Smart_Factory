#pragma once
#include <iostream>
#include <string>
#include <iomanip>
#include <cctype>
using namespace std;

char IsChar(string msg);
int IsNumber(string msg);
int IsValid(int sm, int big, string num);




